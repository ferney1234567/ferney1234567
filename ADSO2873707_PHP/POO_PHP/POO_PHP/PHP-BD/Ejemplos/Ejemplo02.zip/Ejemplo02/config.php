<?php
define("DRIVER","mysql");
define("HOST","localhost");
define("DB_NAME","clientesdb");
define("USER","root");
define("PASSWORD","");
?>